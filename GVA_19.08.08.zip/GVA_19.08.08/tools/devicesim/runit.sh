#!/bin/bash

export NODE_PATH=".";
node devicesim.js
