#!/bin/bash

export NODE_PATH=".";
node devprovtool.js
