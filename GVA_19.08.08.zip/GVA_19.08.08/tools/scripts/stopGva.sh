#!/bin/bash
docker stop gva
docker rm gva

