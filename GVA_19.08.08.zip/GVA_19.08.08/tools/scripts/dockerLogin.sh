#!/bin/bash
URL=
USERNAME= 
PASSWORD= 
docker login $URL -u $USERNAME -p $PASSWORD
