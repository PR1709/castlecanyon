const Logging   = require('cccommon/logging').logger('shippingapi.route.sensordata');
Logging.enable();

exports.getRoutes = () => {
  const constant = require('cccommon/constant');
  const statusConst = constant.status;
  const roleConst = constant.role;
  const tokenAuth = require('this_pkg/auth/token');
  const roleAuth = require('this_pkg/auth/role');
  const basePath = '/sensordata';
  const get = require('./get');
  const del = require('./delete');
  const shipmentDi = require('this_pkg/shipment/di');
//  const validateStatusTransition = require('this_pkg/sensordata/status').validateTransition;
//  const validateStatusLockOwner = require('this_pkg/sensordata/statusLock').validateOwner;
  const exposeDeveloperEndpoints = require('cccommon/config').shippingapi.exposeDeveloperEndpoints();

  const routes = [
    /**
     * RETRIEVE / FETCH / QUERY
     */
    {
      method: 'get',
      path: basePath +'/:id',
      tokenAuthWrapper: tokenAuth.REQUIRED,
      roleAuthWrapper: roleAuth.REQUIRED(
        [
          roleConst.name.deskAgent(),
          roleConst.name.dockWorker()
        ]
      ),
      customWrappers: [ // first wrapper listed is first to wrap the handler
        //shipmentDi
      ],
      handler: get.list
    },
    {
          method: 'delete',
          path: basePath + '/delete/:id',
          tokenAuthWrapper: tokenAuth.REQUIRED,
          roleAuthWrapper: roleAuth.REQUIRED(
              [
                  roleConst.name.deskAgent(),
                  roleConst.name.dockWorker()
              ]
          ),
          customWrappers: [ // first wrapper listed is first to wrap the handler
              //shipmentDi
          ],
          handler: del.all
      }

];
  return routes;
}
