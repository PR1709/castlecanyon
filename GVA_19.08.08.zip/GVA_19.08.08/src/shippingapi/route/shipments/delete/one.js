const Logging = require('cccommon/logging').logger('shippingapi.route.shipment.delete.one');
Logging.enable();

const shipDal = require('cccommon/dal/shipment');
const appErr = require('this_pkg/error');

module.exports = async (req, res, user, shipment) => {
  try {
    await shipDal.deleteOne(req, shipment);
  } catch(err) {
    appErr.handleRouteServerErr(req, res, err, Logging, 'failed to delete shipment');
    return;
  }

  res.status(204).send();
};
