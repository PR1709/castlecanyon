const Logging = require('cccommon/logging').logger('shippingapi.route.shipment.delete.photos');
Logging.enable();

const blobContainer = require('cccommon/config').shippingapi.photo.blobhelper.container();
const blobHelper = require('cccommon/blobhelper').helper(blobContainer);

const shipDal = require('cccommon/dal/shipment');
const appErr = require('this_pkg/error');
const photoConst = require('cccommon/constant').photo;
const ValidationError = require('cccommon/dal').error.ValidationError;

module.exports = async (req, res, user, shipment) => {
  const successStatus = 204;

  try {
    const type = req.params.type;

    const valErrs = [];
    if (!photoConst.type.exists(type)) {
      valErrs.push({
        type: 'invalid',
        allowedTypes: photoConst.type.all()
      });
    }
    if (valErrs.length) {
      appErr.send(req, res, 'input_validation_failed', appErr.mergeValErrList(valErrs));
      return;
    }

    const existingUrl = shipDal.photoUrl(shipment, type);

    if (existingUrl === '') {
      res.status(successStatus).send();
      return;
    }

    // Delete the URL from the shipment record first because it's preferrable for the VP to
    // believe there's no photo than receive a URL to a file that no longer exists.
    await shipDal.deletePhoto(shipment, type);

    await blobHelper.deleteBlobPromisified(existingUrl);
  } catch(createErr) {
    if (createErr instanceof ValidationError) {
      exports.handleDbValidationError(req, res, createErr);
    } else {
      appErr.handleRouteServerErr(req, res, createErr, Logging, 'failed to delete photo');
    }
    return;
  }

  res.status(successStatus).send();
};
