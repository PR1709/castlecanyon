const request = require('request');
const Logging = require('cccommon/logging').logger('shippingapi.route.shipment.post');
Logging.enable();
const appErr = require('this_pkg/error');
const createDevice = require('cccommon/gwsendrecv/auth');
const idgen = require('cccommon/idgen/idgen');
const security = require('cccommon/security/security');
const config = require('cccommon/config/config');

exports.handler = async (req, res, user, shipment) => {
  Logging.msg("Shipment: " + shipment);
  const successStatus = 201;
  const deviceUuid = req.body.deviceUuid;
  const obtEcdsaPublicKey = req.body.obtEcdsaPublicKey;
  const valErrs = [];

  if (!deviceUuid) {
    valErrs.push({deviceUuid: 'missing'});
  }
  if (deviceUuid.length != 32) {
    valErrs.push({deviceUuid: 'Invalid UUID'});
  }
  if (!obtEcdsaPublicKey) {
    valErrs.push({obtEcdsaPublicKey: 'missing'});
  }
  if (valErrs.length) {
    appErr.send(req, res, 'input_validation_failed', appErr.mergeValErrList(valErrs));
    return;
  }

  var keystoreQuery = {
      UUID: deviceUuid,
      challenge: 'GVA-Challenge',
      response: 'GW-Response'
  };
  var requestOption = {
     url: config.deviceKeystore.uri() + 'keystore/authenticate/',
     qs: keystoreQuery
  };
  request.get(requestOption, function(error, response, body){
     Logging.msg("Response: " + JSON.stringify(response));
     Logging.msg("Body: " + body);
     if(!response) {
       res.status(202).send({result: "Keystore server is not responding"});
       return;
     }
     if(response.statusCode == 200){
       buildResponse(body, shipment, deviceUuid, obtEcdsaPublicKey, res);
       return;
     } else{
       res.status(202).send(body);
       return;
     }
  });
}

async function buildResponse(keystoreDeviceCredentials, shipment, deviceUuid, obtEcdsaPublicKey, res){
  keystoreDeviceCredentials = JSON.parse(keystoreDeviceCredentials);
  let update = await createDevice(deviceUuid)
  .then(async function(resolve) {
     // Build Session Credentials
     deviceObj = resolve;
     var response = {};
     var sessionCredentialsPayload = {};
     sessionCredentialsPayload.gvaEcdsaPublicKeyCertificate = security.getGvaEcdsaPublicKeyCert();
     sessionCredentialsPayload.gvaEcdhPublicKey = security.getGvaEcdhPublicKey();
     sessionCredentialsPayload.sessionNonce = idgen.get_session_nonce();
     sessionCredentialsPayload.shipmentId = shipment.id;
     sessionCredentialsPayload.obtEcdsaPublicKey = obtEcdsaPublicKey;

     response.sessionCredentials = {};
     response.sessionCredentials.payload = JSON.stringify(sessionCredentialsPayload);
     response.sessionCredentials.header = security.signEs256(response.sessionCredentials.payload);
  
     var gwConnectionCredentialsPayload = {};
     gwConnectionCredentialsPayload.commonBeaconKey = idgen.get_common_beacon_key();
     gwConnectionCredentialsPayload.iotConnectionType = "IOTHUB";
     gwConnectionCredentialsPayload.connectionProperties = {};
     gwConnectionCredentialsPayload.connectionProperties.iotHubUri = deviceObj.uri;
     gwConnectionCredentialsPayload.connectionProperties.deviceId = deviceObj.deviceId;
     gwConnectionCredentialsPayload.connectionProperties.primaryKey = deviceObj.authentication.symmetricKey.primaryKey;
     gwConnectionCredentialsPayload.connectionProperties.secondaryKey = deviceObj.authentication.symmetricKey.secondaryKey;
     var gwConnectionCredentialsPayloadString = JSON.stringify(gwConnectionCredentialsPayload);
     var gwConnectionCredentialsPayloadStringEncrypted = security.encryptAes128UsingEcdhPubliKey(keystoreDeviceCredentials.deviceEcdhPublicKey, gwConnectionCredentialsPayloadString);

     response.gwConnectionCredentials = {};
     response.gwConnectionCredentials.payload = gwConnectionCredentialsPayloadStringEncrypted;
     response.gwConnectionCredentials.header = security.signEs256(response.gwConnectionCredentials.payload);

     response.gwCredentials = {};
     response.gwCredentials.deviceUuid = deviceUuid;
     response.gwCredentials.publickey = keystoreDeviceCredentials.signedEcdsaPublicKeyCertificate;     
     response.debug = {};
     response.debug.gwConnectionCredentialsPayload = gwConnectionCredentialsPayload;
     response.debug.sessionCredentialsPayload = sessionCredentialsPayload;
 
     Logging.msg("response: " + response);

     res.status(201).send(response);
     return;
  })
  .catch(async function(reject) {
      Logging.msg("Error creating new GW device in IOT HUB: " + reject);
      res.status(202).send({result:"Error creating new GW device in IOT HUB"});
      return;
  })
}
