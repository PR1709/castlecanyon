const Logging = require('cccommon/logging').logger('shippingapi.route.shipment.post.provision.verify');
Logging.enable();

const request = require('request-promise');
const dal = require('cccommon/dal');
const shipDal = dal.shipment;
const appErr = require('this_pkg/error');

module.exports = async (req, res, user, shipment) => {
  let transaction;
  let options = {};
  try {
    const spec = req.body;
    Logging.msg("body: " + JSON.stringify(spec));
    const valErrs = await exports.validateSpec(shipment, spec, options);
    if (valErrs.length) {
      appErr.send(req, res, 'input_validation_failed', appErr.mergeValErrList(valErrs));
      return;
    }
  } catch(err) {
    appErr.handleRouteServerErr(req, res, err, Logging, 'failed to change shipment status');
    return;
  }

  var response = {};
  res.status(204).send(response);
};

exports.validateSpec = async (shipment, spec, options) => {
  const valErrs = [];

  if (!spec.gateways || !Array.isArray(spec.gateways)) {
    valErrs.push({gateways: 'missing'});
    return valErrs;
  }

  if (!spec.tags || !Array.isArray(spec.tags)) {
    valErrs.push({tags: 'missing'});
    return valErrs;
  }
  
  for(let i in spec.gateways) {
    const gatewayConflicts = await shipDal.findByGatewayUUID(spec.gateways[i], options);
    if (gatewayConflicts.length) {
      let shipIds = [];
      for (let ship of gatewayConflicts) {
        shipIds.push(ship.get('id'));
      }
      shipIds = shipIds.join(', ');
      const ve = {};
      ve[spec.gateways[i]] = `gateway [${spec.gateways[i]}] is in use by shipment [ID: ${shipIds}]`;
      valErrs.push(ve);
    }
  }

  for(let i in spec.tags) {
    const tagConflicts = await shipDal.findByTagUUID(spec.tags[i], options);
    if (tagConflicts.length) {
      let shipIds = [];
      for (let ship of tagConflicts) {
        shipIds.push(ship.get('id'));
      }
      shipIds = shipIds.join(', ');
      const ve = {};
      ve[spec.tags[i]] = `tag [${spec.tags[i]}] is in use by shipment [ID: ${shipIds}]`;
      valErrs.push(ve);
      }
  }
  
  return valErrs;
}
