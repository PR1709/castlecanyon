const Logging = require('cccommon/logging').logger('shippingapi.route.shipment.put.receive.deinstrument');
Logging.enable();

const dal = require('cccommon/dal');
const shipDal = dal.shipment;
const statusConst = require('cccommon/constant').status;
const appErr = require('this_pkg/error');
const statusHelper = require('this_pkg/shipment/status');
const updateDeviceRecord = require('cccommon/keystore');

module.exports = async (req, res, user, shipment) => {
  const fromStatus = shipment.status;
  let toStatus;
  let transaction;

  try {
    if (fromStatus === statusConst.accepted()) {
      toStatus = statusConst.acceptedDeinstrumented();
    } else if (fromStatus === statusConst.rejected()) {
      toStatus = statusConst.rejectedDeinstrumented();
    } else if (fromStatus === statusConst.completed()) {
      toStatus = statusConst.completedDeinstrumented();
    } else {
      // Middleware that validates status transitions should not let this case happen.
      // Catch it in case there's a regression.
      throw new Error(`deinstrument handler encountered an unexpected from-status [${fromStatus}]`);
    }

    //remove the gatway Id <--> shipment Id association in KeyStore
    let plainShipment = shipment.get({
      plain: true
    });
    let gatewayUuid = plainShipment.gateways[0].uuid
    Logging.msg("GatewayId: " + gatewayUuid);

    await updateDeviceRecord(gatewayUuid)
    .then(async function (result) {
      Logging.msg("Keystore has been updated!!");

      transaction = await dal.getTransaction();
      await shipDal.deinstrument(req, shipment, toStatus, {transaction: transaction});
      await transaction.commit();

      statusHelper.logTransitionSuccess(req, Logging, user, shipment, fromStatus, toStatus);
      res.status(204).send();
    })
    .catch(function (error) {
      err += "Error while trying to update Keystore: " + error + ";";
      Logging.msg(err);
      appErr.send(req, res, 'other;', ["there was and error when tyring to update gw device in Keystore"]);
      return;
    });
  } catch(err) {
    if (transaction) {
      await transaction.rollback();
    }
    appErr.handleRouteServerErr(req, res, err, Logging, 'failed to change shipment status');
    return;
  }
};
