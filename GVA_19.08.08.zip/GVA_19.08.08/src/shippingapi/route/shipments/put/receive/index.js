const Logging = require('cccommon/logging').logger('shippingapi.route.shipment.put.receive');
Logging.enable();

const shipDal = require('cccommon/dal/shipment');
const statusConst = require('cccommon/constant').status;
const appErr = require('this_pkg/error');
const statusHelper = require('this_pkg/shipment/status');
const gwmClient = require('cccommon/client/gwmessenger');

module.exports = async (req, res, user, shipment) => {
  const fromStatus = shipment.status;
  const userRoleNames = []
  user.roles.forEach(role => {
    userRoleNames.push(role.name);
  });
  Logging.msg("Receive User: " + user.get('id') + ", Role: " + userRoleNames[0]);

  if (userRoleNames[0] == "Dock Worker") { // OBT flow
    try {
      await shipDal.updateStatusAndLock(shipment, statusConst.inReceiving(), user);
    } catch(err) {
      appErr.send(req, res, 'other', 'failed to change shipment status');
      return;
    }
    statusHelper.logTransitionSuccess(req, Logging, user, shipment, fromStatus, statusConst.inReceiving());
  } else { // non-OBT flow
    try {
      let plainShipment = shipment.get({plain:true});
      Logging.msg("ShipmentId: " + plainShipment.id);
      Logging.msg("GatewayId: " + plainShipment.gateways[0].uuid);
      req.body.gatewayId = plainShipment.gateways[0].uuid;
      await gwmClient.startReceving(req, plainShipment.id);
    } catch (gwmErr) {
      Logging.msg('Failed to send north-to-south msg to start receive process');
      appErr.send(req, res, 'other', 'failed to send receive command to the gateway');
      return;
    }
  }

  res.status(204).send();
};

