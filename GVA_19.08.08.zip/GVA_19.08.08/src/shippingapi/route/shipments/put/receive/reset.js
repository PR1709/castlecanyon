const Logging = require('cccommon/logging').logger('shippingapi.route.shipment.put.receive.reset');
Logging.enable();

const shipDal = require('cccommon/dal/shipment');
const statusConst = require('cccommon/constant').status;
const appErr = require('this_pkg/error');
const statusHelper = require('this_pkg/shipment/status');

module.exports = async (req, res, user, shipment) => {
  const fromStatus = shipment.status;

  try {
    await shipDal.updateStatusAndUnlock(shipment, statusConst.inMonitoring());
  } catch(err) {
    appErr.handleRouteServerErr(req, res, err, Logging, 'failed to change shipment status');
    return;
  }

  statusHelper.logTransitionSuccess(req, Logging, user, shipment, fromStatus, statusConst.inMonitoring());

  res.status(204).send();
};
