const Logging = require('cccommon/logging').logger('shippingapi.route.shipment.put.photos');
Logging.enable();

const blobContainer = require('cccommon/config').shippingapi.photo.blobhelper.container();
const blobHelper = require('cccommon/blobhelper').helper(blobContainer);

const shipDal = require('cccommon/dal/shipment');
const appErr = require('this_pkg/error');
const photoConst = require('cccommon/constant').photo;
const ValidationError = require('cccommon/dal').error.ValidationError;

module.exports = async (req, res, user, shipment) => {
  const successStatus = 201;
  let spec = req.body;
  let action;

  try {
    const type = req.params.type;

    const valErrs = exports.validateSpec(spec);
    if (!photoConst.type.exists(type)) {
      valErrs.push({
        type: 'invalid',
        allowedTypes: photoConst.type.all()
      });
    }
    if (valErrs.length) {
      appErr.send(req, res, 'input_validation_failed', appErr.mergeValErrList(valErrs));
      return;
    }

    const existingUrl = shipDal.photoUrl(shipment, type);
    if (existingUrl === '') {
      spec.url = await blobHelper.uploadBlobPromisified(spec.data, spec.contentType);
      action = photoConst.action.create();
    } else {
      spec.url = await blobHelper.replaceBlobPromisified(existingUrl, spec.data, spec.contentType);
      action = photoConst.action.replace();
    }

    spec = exports.finalizeSpec(spec);

    await shipDal.updatePhoto(shipment, type, spec);
  } catch(createErr) {
    if (createErr instanceof ValidationError) {
      exports.handleDbValidationError(req, res, createErr);
    } else {
      appErr.handleRouteServerErr(req, res, createErr, Logging, 'failed to upload photo');
    }
    return;
  }

  res.status(successStatus).send({url: spec.url, action: action});
};

exports.validateSpec = (spec) => {
  const valErrs = [];

  function present(v) {
    return v && v != '';
  }

  if (!present(spec.data)) {
    valErrs.push({data: 'missing/empty'});
  }
  if (!present(spec.contentType)) {
    valErrs.push({contentType: 'missing/empty'});
  }

  return valErrs;
};

exports.finalizeSpec = (spec) => {
  return {
    url: spec.url,
    contentType: spec.contentType,
    note: spec.note || ''
  };
};
