const Logging = require('cccommon/logging').logger('shippingapi.route.shipment.put.provision');
Logging.enable();

const dal = require('cccommon/dal');
const shipDal = dal.shipment;
const statusConst = require('cccommon/constant').status;
const appErr = require('this_pkg/error');
const statusHelper = require('this_pkg/shipment/status');
const createDevice = require('cccommon/gwsendrecv/auth');
const updateDeviceRecord = require('cccommon/keystore');

module.exports = async (req, res, user, shipment) => {
  const fromStatus = shipment.status;
  let transaction;
  let err = '';

  try{
    if (Object.keys(req.body).length != 0) {  // non-OBT flow
      const valErrs = await exports.validateSpec(shipment, req.body, null);
      if (valErrs.length) {
        appErr.send(req, res, 'input_validation_failed', appErr.mergeValErrList(valErrs));
        return;
      }
      // update the keystore/randevouz server with the gw-shipment ID association
      // first get iot hub auth keys for the gateway
      let update = await createDevice(req.body.gateways[0])
              .then(async function(result) {
                //Logging.msg("Device created: " + JSON.stringify(result));
                var connectionString=
                  "HostName=" + result.uri + ";" +
                  "DeviceId=" + result.deviceId + ";" +
                  "SharedAccessKey=" + result.authentication.symmetricKey.primaryKey;
                var deviceCredentials = {
                  uri: result.uri,
                  deviceId: result.deviceId,
                  primaryKey: result.authentication.symmetricKey.primaryKey,
                  secondaryKey: result.authentication.symmetricKey.secondaryKey,
                  connectionString: connectionString
                  }
                return await updateDeviceRecord(
                    req.body.gateways[0],
                    shipment.id,
                    req.protocol + '://' + req.headers.host,
                    deviceCredentials,
                    {
                      username: "dockworker@localhost",
                      password: "dockworker",
                      role: "Dock Worker"
                    }
                    )
                  .then(function(result){
                    Logging.msg("Keystore has been updated!!");
                    return true;
                  })
                  .catch(function(error){
                    err += "Error while trying to update Keystore: " + error + ";";
                    Logging.msg(err);
                    return false;
                  });
              })
              .catch(function(err) {
                if(error){
                  err += "error creating device: " + error + ";";
                  Logging.msg(err);
                  return false;
                }
              });
      if(!update){
        appErr.send(req, res, 'other;', ["there was and error when tyring to reigster gw device"]);
        return;
      }
      shipDal.addGatewayIdToShipment(shipment, req.body, null);
    }
    await shipDal.updateStatusAndLock(shipment, statusConst.inProvision(), user);
    statusHelper.logTransitionSuccess(req, Logging, user, shipment, fromStatus, statusConst.inProvision());
    res.status(204).send();
    return;
  } catch(error) {
    err += "Provision shipment Error: " + error + ";";
    Logging.msg(err);
    if (transaction) {
      await transaction.rollback();
    }
    appErr.handleRouteServerErr(req, res, err, Logging, 'failed to change shipment status');
    return;
  }
}

exports.validateSpec = async (shipment, spec, options) => {
  const valErrs = [];

  function present(v) {
    return v && v != '';
  }

  if (!spec.gateways || !Array.isArray(spec.gateways) || spec.gateways.length === 0) {
    valErrs.push({gateways: 'missing/empty: for OBT flow please send empty body; for non-OBT flow send body with JSON with gateways array'});
    return valErrs;
  }

  //TODO: supports only one Gateway per shipment
  let gateway = spec.gateways[0];
  const gatewayConflicts = await shipDal.findByGatewayUUID(gateway, options);
  if (gatewayConflicts.length) {
    let shipIds = [];
    for (let ship of gatewayConflicts) {
      Logging.msg("ship.get: " + ship.get('id'));
      Logging.msg("shipment.id " + shipment.id);
      if(ship.get('id') != shipment.id)
        shipIds.push(ship.get('id'));
    }
    if (shipIds.length) {
      shipIds = shipIds.join(', ');
      valErrs.push({'gateway[0]': `gateway [${gateway}] is in use by shipment [ID: ${shipIds}]`});
      return valErrs;
    }
  }

  return valErrs;
}
