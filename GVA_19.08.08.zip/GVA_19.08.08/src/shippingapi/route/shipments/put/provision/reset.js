const Logging = require('cccommon/logging').logger('shippingapi.route.shipment.put.provision.reset');
Logging.enable();

const shipDal = require('cccommon/dal/shipment');
const statusConst = require('cccommon/constant').status;
const appErr = require('this_pkg/error');
const statusHelper = require('this_pkg/shipment/status');
const uuid = require('uuid/v4');
const updateDeviceRecord = require('cccommon/keystore');

module.exports = async (req, res, user, shipment) => {
  const fromStatus = shipment.status;

  try {
    await shipDal.updateStatusAndUnlock(shipment, statusConst.new());
  } catch (err) {
    appErr.handleRouteServerErr(req, res, err, Logging, 'failed to change shipment status');
    return;
  }

  //remove the gatway Id <--> shipment Id association in KeyStore
  let plainShipment = shipment.get({
    plain: true
  });
  let gatewayUuid = plainShipment.gateways[0].uuid
  Logging.msg("GatewayId: " + gatewayUuid);

  await updateDeviceRecord(gatewayUuid)
    .then(function (result) {
      Logging.msg("Keystore has been updated!!");

      //replace associated GW ID from shipement and replace with token string
      let body = {
        gateways: [uuid()]
      }
      shipDal.addGatewayIdToShipment(shipment, body, null);

      // modify state back to new
      statusHelper.logTransitionSuccess(req, Logging, user, shipment, fromStatus, statusConst.new());
      res.status(204).send();
    })
    .catch(function (error) {
      let err = "Error while trying to update Keystore: " + error + ";";
      Logging.msg(err);
      appErr.send(req, res, 'other;', ["there was and error when tyring to update gw device in Keystore"]);
      return;
    });
};
