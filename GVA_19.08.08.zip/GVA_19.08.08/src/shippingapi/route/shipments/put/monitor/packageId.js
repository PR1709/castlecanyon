const Logging = require('cccommon/logging').logger('shippingapi.route.shipment.put.monitor.packageId');
Logging.enable();

const dal = require('cccommon/dal');
const shipDal = dal.shipment;
const statusConst = require('cccommon/constant').status;
const appErr = require('this_pkg/error');

module.exports = async (req, res, user, shipment) => {
  let options;
  try {
    if (shipment.status !== statusConst.inMonitoring()) {
      appErr.send(
        req, res, 'status_conflict',
        'Package IDs can only be updated when Shipment is in Monitoring State', {
          currentStatus: shipment.status,
          requiredStatus: statusConst.inMonitoring()
        }
      );
      return;
    }
    const spec = req.body;
    const valErrs = await exports.validateSpec(shipment, spec, options);
    if (valErrs.length) {
      appErr.send(req, res, 'input_validation_failed', appErr.mergeValErrList(valErrs));
      return;
    }

    shipDal.updatePackageIds(shipment, req.body, options);
    res.status(204).send();
  } catch (err) {
    appErr.handleRouteServerErr(req, res, err, Logging, 'failed to change shipment status');
    return;
  }
};

exports.validateSpec = async (shipment, spec, options) => {
  const valErrs = [];

  function present(v) {
    return v && v != '';
  }

  return valErrs;
};
