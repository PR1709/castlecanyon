const Logging = require('cccommon/logging').logger('shippingapi.route.shipment.put.monitor');
Logging.enable();

const request = require('request-promise');
const config = require('cccommon/config/config');
const dal = require('cccommon/dal');
const shipDal = dal.shipment;
const statusConst = require('cccommon/constant').status;
const appErr = require('this_pkg/error');
const statusHelper = require('this_pkg/shipment/status');
const hooks = require('this_pkg/hooks');
const securityEnable = require('cccommon/config').security.enable();
const idgen = require('cccommon/idgen/idgen');

module.exports = async (req, res, user, shipment) => {
  const fromStatus = shipment.status;
  let transaction;
  let options;
  let securityValidation;
  try {
    const spec = req.body;

    transaction = await dal.getTransaction();
    options = {transaction: transaction};

    const valErrs = await exports.validateSpec(shipment, spec, options);
    if (valErrs.length) {
      if (transaction) {
        await transaction.rollback();
      }

      appErr.send(req, res, 'input_validation_failed', appErr.mergeValErrList(valErrs));
      return;
    }

/*    if (securityEnable) {
      securityValidation = await validateChallengeResponses(shipment, spec);
      if (securityValidation.result == "fail") {
        if (transaction) {
          await transaction.rollback();
        }
        Logging.msg("securityValidation: " + JSON.stringify(securityValidation));
        appErr.send(req, res, 'security_validation_failed', appErr.mergeValErrList([{"reason":securityValidation.reason}]));
        return;
      }
    }
*/
    await shipDal.updateStatusAndUnlock(shipment, statusConst.inMonitoring(), options);
    await shipDal.initMonitorConfig(shipment, spec, options);

    await transaction.commit();
  } catch(err) {
    if (transaction) {
      await transaction.rollback();
    }

    appErr.handleRouteServerErr(req, res, err, Logging, 'failed to change shipment status');

    return;
  }

  statusHelper.logTransitionSuccess(req, Logging, user, shipment, fromStatus, shipment.status);

  //call monitor hook
  //hooks.shipment.monitor(shipment.get('id'));

  //compose the response
  var response = {};
/*  if (securityEnable) {
    response.header = {
                    "signingAlgorithm": "ECDSA",
                    "hashMethod": "SHA256",
                    "signatureEncoding": "base64",
                    "signedBy": "GVA",
                    "signature": "Dummy Signature"
                };
    response.payload = {};
    response.payload.beaconSecrets = [];

    for(var device of securityValidation.challengeResponseArray){
      response.payload.beaconSecrets.push({"uuid": device.deviceUuid, "encryptedBeaconSecret": device.secretBeaconKey});
    } 
  }
*/
  res.status(204).send(response);
};

validateChallengeResponses = async (shipment, spec) => {
  let challengeResponseJson = {};
  let challengeResponseArray = [];
  const gateway = spec.gateways[0];
  // Build the array
  for (let su in gateway.shippingUnits) {
    const shippingUnit = gateway.shippingUnits[su];
    for (let t in shippingUnit.tags) {
      const tag = shippingUnit.tags[t];
      challengeResponseArray.push({"deviceUuid": tag.id, "challengeResponse":tag.challengeResponse, "deviceEcdhPublicKey":tag.ecdhPublicKey});
    }
  }
  Logging.msg("ChallengeResponseArray: " + JSON.stringify(challengeResponseArray));
  //query the device record
  try {
      for(var device of challengeResponseArray){
        await getDeviceRecord(device.deviceUuid)
          .then(function(response) {
             Logging.msg('StatusCode: ' + response.statusCode +
                          '\nHeader: ' + JSON.stringify(response.headers)  +
                          '\nBody: ' + response.body);
             if(response.statusCode == 200) {
               let body = JSON.parse(response.body);
               Logging.msg('\ndevice.challengeResponse: ' + device.challengeResponse + '\nresponse.body.deviceEcdhPublicKey: ' + body.deviceEcdhPublicKey);
               Logging.msg('device.ecdhPublicKey: ' + device.deviceEcdhPublicKey);
               
               //let challengeResponseIsValid = security.validateChallengeResponse(idgen.get_session_nonce(), device.deviceUuid, device.deviceEcdhPublicKey, device.challengeResponse);
               
               let challengeResponseIsValid = security.validateChallengeResponse(idgen.get_session_nonce(), device.deviceUuid, body.deviceEcdhPublicKey, device.challengeResponse);
               if(challengeResponseIsValid){
                 device.deviceEcdhPublicKey = body.deviceEcdhPublicKey;
                 device.secretBeaconKey = security.encryptAes128UsingEcdhPubliKey(device.deviceEcdhPublicKey, idgen.get_common_beacon_key());
                 Logging.msg('Validated device: ' + device.deviceUuid + ' and generated Secret Beacon Key: ' + device.secretBeaconKey);
                 challengeResponseJson.result = 'pass';
               } else {
                 Logging.msg("Error: Challenge-Response Failure for Device: " + device.deviceUuid);
                 challengeResponseJson.result = 'fail';
                 challengeResponseJson.reason = "Challenge-Response Failure for Device: " + device.deviceUuid;
               }
             } else {
               Logging.msg("Error: Device does not exist in Keystore: " + device.deviceUuid);
               challengeResponseJson.result = 'fail';
               challengeResponseJson.reason = "Device does not exist in Keystore: " + device.deviceUuid;
             }
          })
          .catch(function(err) {
             Logging.msg("Try-Catch Error: " + err); 
             challengeResponseJson.result = 'fail';
             challengeResponseJson.reason = "Try-Catch Error: " + err;
          });
      };
        Logging.msg("Completed ChallengeResponse Validation Returning to main funciton");
        if(challengeResponseJson.result == 'pass')
          challengeResponseJson.challengeResponseArray = challengeResponseArray;
        return challengeResponseJson;
  } catch (error) {
      Logging.msg('Try-Catch error: ' + error);
      return null;
  }
}

getDeviceRecord = (deviceUuid) => {
    var _include_headers = function(body, response, resolveWithFullResponse) {
        return {'statusCode': response.statusCode, 'headers': response.headers, 'body': body};
      };
    var keystoreQuery = {
        UUID: deviceUuid,
        challenge: 'GVA-Challenge',
        response: 'GW-Response'
    };
    var requestOption = {
        url: config.deviceKeystore.uri() + 'keystore/authenticate/',
        qs: keystoreQuery,
        transform: _include_headers
    };
    return request.get(requestOption);
}

exports.validateSpec = async (shipment, spec, options) => {
  const valErrs = [];
  const shipmentId = shipment.get('id');
  function present(v) {
    return v && v != '';
  }

  if (!spec.gateways || !Array.isArray(spec.gateways) || spec.gateways.length === 0) {
    valErrs.push({gateways: 'missing/empty'});
    return valErrs;
  }

  // For December, there will only be one gateway.
  const gateway = spec.gateways[0];

  if (!present(gateway.id)) {
    valErrs.push({'gateway[0].id': 'missing/empty'});
    return valErrs;
  }

  const gatewayConflicts = await shipDal.findByGatewayUUID(gateway.id, options);
  if (gatewayConflicts.length) {
    let shipIds = [];
    for (let ship of gatewayConflicts) {
      let conflictId = ship.get('id');
      if(shipmentId != conflictId)
        shipIds.push(conflictId);
    }
    if(shipIds.lenght){
      shipIds = shipIds.join(', ');
      valErrs.push({'gateway[0].id': `gateway [${gateway.id}] is in use by shipment [ID: ${shipIds}]`});
      return valErrs;
    }
  }

  if (!Array.isArray(gateway.shippingUnits) || gateway.shippingUnits.length === 0) {
    valErrs.push({'gateway[0].shippingUnits': 'missing/empty'});
    return valErrs;
  }

  if (gateway.shippingUnits.length !== shipment.shippingUnitCount) {
    valErrs.push({'gateway[0].shippingUnits': `received ${gateway.shippingUnits.length}, expected ${shipment.shippingUnitCount}`});
  }

  for (let su in gateway.shippingUnits) {
    const shippingUnit = gateway.shippingUnits[su];

    if (!present(shippingUnit.id)) {
      const key = `gateway[0].shippingUnit[${su}].id`;
      const ve = {};
      ve[key] = 'missing/empty';
      valErrs.push(ve);
      return valErrs;
    }

    if (!Array.isArray(shippingUnit.tags) || shippingUnit.tags.length === 0) {
      const key = `gateway[0].shippingUnit[${su}].tags`;
      const ve = {};
      ve[key] = 'missing/empty';
      valErrs.push(ve);
      return valErrs;
    }

    for (let t in shippingUnit.tags) {
      const tag = shippingUnit.tags[t];
      const key = `gateway[0].shippingUnit[${su}].tags[${t}].id`;

      if (!present(tag.id)) {
        const ve = {};
        ve[key] = 'missing/empty';
        valErrs.push(ve);
        return valErrs;
      }

/*      if (securityEnable) {
        const keyChallengeResponse=`gateway[0].shippingUnit[${su}].tags[${t}].challengeResponse`;
        if (!present(tag.challengeResponse)) {
          const ve = {};
          ve[keyChallengeResponse] = 'missing/empty';
          valErrs.push(ve);
          return valErrs;
        }
      }
*/
      const tagConflicts = await shipDal.findByTagUUID(tag.id, options);
      if (tagConflicts.length) {
        let shipIds = [];
        for (let ship of tagConflicts) {
          shipIds.push(ship.get('id'));
        }

        // DECEMBER HACK: while DB unique constraints have been off, multiple conflicts may have accrued.
        shipIds = shipIds.join(', ');

        const ve = {};
        ve[key] = `tag [${tag.id}] is in use by shipment [ID: ${shipIds}]`;
        valErrs.push(ve);
        return valErrs;
      }
    }
  }

  return valErrs;
};
