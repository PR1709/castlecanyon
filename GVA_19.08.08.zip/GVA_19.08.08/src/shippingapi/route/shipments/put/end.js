const Logging = require('cccommon/logging').logger('shippingapi.route.shipment.put.end');
Logging.enable();

const shipDal = require('cccommon/dal/shipment');
const statusConst = require('cccommon/constant').status;
const appErr = require('this_pkg/error');
const statusHelper = require('this_pkg/shipment/status');

module.exports = async (req, res, user, shipment) => {
  const fromStatus = shipment.status;
  let toStatus;

  try {
    if (fromStatus === statusConst.accepted()) {
      toStatus = statusConst.completed();
    } else if (fromStatus === statusConst.acceptedDeinstrumented()) {
      toStatus = statusConst.completedDeinstrumented();
    } else {
      // Middleware that validates status transitions should not let this case happen.
      // Catch it in case there's a regression.
      throw new Error(`end handler encountered an unexpected from-status [${fromStatus}]`);
    }

    await shipDal.updateStatus(shipment, toStatus);
  } catch(err) {
    appErr.handleRouteServerErr(req, res, err, Logging, 'failed to change shipment status');
    return;
  }

  statusHelper.logTransitionSuccess(req, Logging, user, shipment, fromStatus, toStatus);

  res.status(204).send();
};
