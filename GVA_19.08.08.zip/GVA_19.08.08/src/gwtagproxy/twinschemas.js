/*
  File: twinschemas.js

  Description:
  Twin schemas and related data structures that are used
  to update reported properties in a tag's device twin
  on receipt of tag sensor data

  License:
  Intel TODO

*/

'use strict';

/*
  map fields from sensordata into the base reported properties
*/
exports.map_base = function(sensordata) {

    return {
	Type                  : sensordata.shipmentId.toString(),
	Firmware              : "1.0.0",
	FirmwareUpdateStatus  : "",
	Location              : "Field",
	Latitude              : sensordata.location.latitude,
	Longitude             : sensordata.location.longitude,
	Protocol              : "MQTT",
	SupportedMethods      : "Reboot,FirmwareUpdate,EmergencyValveRelease,IncreasePressure",
    };
};

exports.map_location_fields = function(sensordata) {
    return {
	latitude    : sensordata.location.latitude,
	longitude   : sensordata.location.longitude,
	speed       : ((Math.random() * 100) - 1),
	speed_unit: 'kmph'
    };
}

exports.map_sensor_fields = function(type, sensordata_payload_item) {


    var table = {};

    table['light'] = function() {
	return {
	    light      : sensordata_payload_item.currentValue,
	    light_unit : "T",
	};
    };

    table['humidity'] = function () {
	return {
	    humidity      : sensordata_payload_item.currentValue,
	    humidity_unit : "%",
	};
    };

    table['temperature'] = function () {
	return {
	    temperature      : sensordata_payload_item.currentValue,
	    temperature_unit : 'F',
	};
    };

    table['pressure'] = function () {
	return {
	    pressure      : sensordata_payload_item.currentValue,
	    pressure_unit : "psig",
	};
    };

    table['battery'] = function () {
	return {
	    battery      : sensordata_payload_item.currentValue,
	    battery_unit : "V",
	};
    };

    table['shock'] = function () {
	return {
	    shock      : sensordata_payload_item.currentValue,
	    shock_unit : "g",
	};
    };

    table['tilt'] = function () {
	return {
	    tilt      : sensordata_payload_item.currentValue,
	    tilt_unit : "degrees"
	};
    };

    if(! table[type] ) {
	throw new Error("unknown sensor type, unable to map: " + type);
	return;
    }

    return table[type]();

};

const schema_names = {
    light       : 'package-light;v1',
    humidity    : 'package-humidity;v1',
    temperature : 'package-temperature;v1',
    pressure    : 'package-pressure;v1',
    battery     : 'package-battery;v1',
    shock       : 'package-shock;v1',
    tilt        : 'package-tilt;v1',
    location    : 'package-location;v1',
};

exports.schemas = {};
exports.schemas.names = schema_names;
exports.schemas.temperature = {
    TemperatureSchema: {
	Interval: "00:00:05",
	MessageTemplate: "{\"temperature\":${temperature},\"temperature_unit\":\"${temperature_unit}\"}",
	MessageSchema: {
	    Name: schema_names.temperature,
	    Format: "JSON",
	    Fields: {
		temperature: "Double",
		temperature_unit: "Text"
	    }
	}
    }
};

exports.schemas.humidity = {
    HumiditySchema: {
	Interval: "00:00:05",
	MessageTemplate: "{\"humidity\":${humidity},\"humidity_unit\":\"${humidity_unit}\"}",
	MessageSchema: {
	    Name: schema_names.humidity,
	    Format: "JSON",
	    Fields: {
		humidity: "Double",
		humidity_unit: "Text"
	    }
	}
    }
};

exports.schemas.pressure = {
    PressureSchema: {
	Interval: "00:00:05",
	MessageTemplate: "{\"pressure\":${pressure},\"pressure_unit\":\"${pressure_unit}\"}",
	MessageSchema: {
	    Name: schema_names.pressure,
	    Format: "JSON",
	    Fields: {
		pressure: "Double",
		pressure_unit: "Text"
	    }
	}
    }
};

exports.schemas.tilt = {
    TiltSchema: {
	Interval: "00:00:05",
	MessageTemplate: "{\"tilt\":${tilt},\"tilt_unit\":\"${tilt_unit}\"}",
	MessageSchema: {
	    Name: schema_names.tilt,
	    Format: "JSON",
	    Fields: {
		tilt: "Double",
		tilt_unit: "Text"
	    }
	}
    }
};

exports.schemas.shock = {
    ShockSchema: {
	Interval: "00:00:05",
	MessageTemplate: "{\"shock\":${shock},\"shock_unit\":\"${shock_unit}\"}",
	MessageSchema: {
	    Name: schema_names.shock,
	    Format: "JSON",
	    Fields: {
		shock: "Double",
		shock_unit: "Text"
	    }
	}
    }
};

exports.schemas.light = {
    LightSchema: {
	Interval: "00:00:05",
	MessageTemplate: "{\"light\":${light},\"light_unit\":\"${light_unit}\"}",
	MessageSchema: {
	    Name: schema_names.light,
	    Format: "JSON",
	    Fields: {
		light: "Double",
		light_unit: "Text"
	    }
	}
    }
};

exports.schemas.battery = {
    BatterySchema: {
	Interval: "00:00:05",
	MessageTemplate: "{\"battery\":${battery},\"battery_unit\":\"${battery_unit}\"}",
	MessageSchema: {
	    Name: schema_names.battery,
	    Format: "JSON",
	    Fields: {
		battery: "Double",
		battery_unit: "Text"
	    }
	}
    }
};

exports.schemas.location = {
    LocationSchema: {
	Interval: "00:00:05",
	MessageTemplate: "{\"latitude\":${latitude},\"longitude\":${longitude},\"speed\": ${speed},\"speed_unit\":\"${speed_unit}\"}",
	MessageSchema: {
	    Name: schema_names.location,
	    Format: "JSON",
	    Fields: {
		latitude  : "Double",
		longitude : "Double",
		speed     : "Double",
		speed_unit: "Text"
	    }
	}
    }
};

exports.schemas.telemetry = {Telemetry : {}};
Object.assign(exports.schemas.telemetry.Telemetry,
	      exports.schemas.temperature,
	      exports.schemas.humidity,
	      exports.schemas.pressure,
	      exports.schemas.tilt,
	      exports.schemas.shock,
	      exports.schemas.light,
	      exports.schemas.battery,
	      exports.schemas.location
	     );
