/*
  File: gwlistener.js

  Description:
  Main etry point for the gwlistener process / code

  License:
  Intel TODO

*/

'use strict';

/* logging ..*/
const Logging   = require('cccommon/logging').logger("gwtagproxy");
Logging.enable();

/* modules that are part of this tool's codebase */
const Commonconfig    = require('cccommon/config');
const Errorlist       = require('cccommon/errorlist').errorlist;
const Northsouth      = require('cccommon/northsouth');
const Gwsendrecv      = require('cccommon/gwsendrecv');
const Twinschemas     = require('twinschemas');

/* gva common mondules */
const shipDal         = require('cccommon/dal/shipment');
const format          = require('cccommon/format');

/* misc utility modules from npmjs.org */
const Cmdline         = require('commander');
const Async           = require('async');

/* Azure related -- IoT hub and friends (also from npmjs.org */
const IothubService   = require('azure-iothub');
const DeviceProtocol  = require('azure-iot-device-mqtt').Mqtt;
const DeviceClient    = require('azure-iot-device').Client;
const DeviceMessage   = require('azure-iot-device').Message;

var handlertable = {};

handlertable[Northsouth.northbound.msgids.sensordata] = function(msgid, msg) {
    Logging.msg("RX msg: " + msgid);

    //NOTE : this will put out A LOT of data -- only for debug in controlled
    //environments with a few tags and gateways sending sensor data!
    //Logging.msg("RX msg.body dump:", msg.body);

    var sensordatamsg = msg.body;

    var shipmentid = sensordatamsg.shipmentId;
    if(isNaN(shipmentid)) {
	Logging.msg("using shipDal.findByShipmentId for shipment lookup: " + shipmentid);
	var queryFn = shipDal.findByShipmentId;
    }
    else {
	Logging.msg("using shipDal.findByPrimaryKey for shipment lookup: " + shipmentid);
	var queryFn = shipDal.findByPrimaryKey;
    }
    queryFn(shipmentid)
	.then(function(shipment) {

	    if(! shipment ) {
		var msg = "failed to retrieve shipment from dal for shipment id: " + shipmentid;
		Logging.msg(msg);
		return;
	    }

	    sensordatamsg.shipmentId  = shipment.id;

      /* This has been put in series to make it straight forward to observe */
	    //Async.each(sensordatamsg.Payload, function(tagdata, donecb) {
	    Async.eachSeries(sensordatamsg.payload, function(tagdata, donecb) {

		Logging.msg("tagdata dump:", tagdata);
		Logging.msg("about to call send_to_tag_hub() for : " + tagdata.tagId);

		send_to_tag_hub(sensordatamsg, tagdata, shipment, donecb);

	    }, function(err) {
		if(err){
		    Logging.msg("errors routing tag data to tag / pcs2 hub");
		    Logging.msg("err dump: ", err);
		    return;
		}
		Logging.msg("successfully routed tag data to tag / pcs2 hub");
	    });

	},function(err) {
	    Logging.msg("err getting shipment info from dal for updating location data", err);
	});
}

/*
  Sends Tag device messages into a tag sensor data specific IoT hub

  send_to_tag_hub
*/
function send_to_tag_hub(sensordatamsg, tagpayload, shipment, finaldonecb) {

    // Logging.msg("+send_to_tag_hub for TagId: " + tagpayload.TagId +
    // 		" and for hacked in tag device id: " + tagpayload.hack.deviceid);

    /*
      prior to this:
      - the cosmo/mongo DB needs to be updated with shipment configuration template information
        - this is not to be done in this module, but likely on a config change event or similar
          south-to-north response.
        - this might also be done from the shippingapi module when the apppriate data has
          been configured for a shipmentid

      what needs to be done in here:
      - get the desired registry deviceId from the twin using either uuid or shipping id.
        - we'll use this deviceid value to obtain the SAS key so that we can start
          "acting as a tag device"

      - with the registry deviceId in hand, use the registry API to get that devices key
        - we need the key to build a connection string to be able to talk to the iot hub
          "as a tag device"

      -  update device twin "reported" properties with location information from the sensordata msg
        - as a tag would in field

      - send D2C messages to the tag iot hub with sensor data formatted appropriatly for the PCS2 monitoring system
        - as a tag would in field

      4) send tag message to the tag iot hub, using the deviceid.
     */

    /* doing things in a specific order - hence waterfall - but still event loop friendly */
    Async.waterfall([
	function(donecb) {

	    var deviceregistry = IothubService.Registry.fromConnectionString(
		Commonconfig.gwtagproxy.iothub_registry_rw_connect_str()
	    );

	    /* find the device id for our tag, querying the device twin
	       using shipment id and tag wsn id */
	    try {

		var shipmentid = sensordatamsg.shipmentId
		var tagdeviceid = "unknown";
		var srchid = tagpayload.tagId;
		Logging.msg("searching shipment " + shipmentid + " for TagId " + srchid);

		/* now, dive into the shipment and find the tag device id that matches srchid */
		var foundid = false;
		for (var gateway in shipment.gateways) {
		    var shippingUnits = shipment.gateways[gateway].shippingUnits;
		    Logging.msg("working on gateway ");
		    for (var shipunit in shippingUnits) {
			var tags = shippingUnits[shipunit].tags;
			Logging.msg("working on shipunit ");
			for (var tag in tags) {
			    //Logging.msg("tag dump: ", {obj: tags[tag]});
			    Logging.msg("working on tag ");
			    if(tags[tag].wsnId == srchid) {
				tagdeviceid = tags[tag].uuid;
				foundid = true;
				Logging.msg("FOUND tag device id " + tagdeviceid +
					    " for tag wsn id " + srchid);
				break;
			    }
			}
			if(foundid === true) break;
		    }
		    if(foundid === true) break;
		}
		if(foundid === false) {
		    var msg = "no tag matching " + srchid + " in shipment " + shipmentid;
		    donecb(msg);
		    return;
		}
	    }
	    catch(err) {
		var msg = "caught error searching through shipment data for tag uuid/device reg id";
		Logging.msg(msg, err.stack);
		donecb(msg);
		return;
	    }

	    donecb(null, tagdeviceid, deviceregistry);

	},
	function(tagdeviceid, deviceregistry, donecb) {

	    Logging.msg("deviceregistry dump: ", deviceregistry);

	    /* now aquire the twin ...*/
	    deviceregistry.get(tagdeviceid, function(err, deviceobj ) {
		if(err) {
		    Logging.msg("error getting device, err dump: ", err);
		    Logging.msg("error getting device: " + err.name);
		    donecb("error getting device");
		    return;
		}

		Logging.msg("success getting device, deviceobj dump: ", deviceobj);
		donecb(null,
		       deviceregistry._config.host,
		       deviceobj.deviceId,
		       deviceobj.authentication.symmetricKey.primaryKey);
	    });
	},
	function(iothubhost, tagdeviceid, tagkey, donecb) {
	    /*
	       now, ready to work with the iothub  as a tag device ..using the azure-iothub-device package!
	       in this section - we update the twin properties with location information
	     */

	    /*
	      build a connect string to connect AS device, then update reported properties
	      HostName=cc-gw-iothub.azure-devices.net;DeviceId=gw-1;SharedAccessKey=KEY-FROM-REGISTRY
	    */
	    var tagconnstr = "HostName=" + iothubhost + ";DeviceId=" + tagdeviceid + ";SharedAccessKey=" + tagkey;

	    var taghubclient = DeviceClient.fromConnectionString(tagconnstr,DeviceProtocol);

	    taghubclient.getTwin(function(err, tagtwin) {
    		if(err) {
    		    Logging.msg("errors getting device twin, err dump: ", err);
    		    Logging.msg("errors getting device twin:" + err.name);
    		    donecb("error getting device twin: " + err.name);
    		    return;
    		}

		// dumptwin(tagtwin);
		Logging.msg("sensordatamsg, dump: ", sensordatamsg);

		var reportedprops = {};
		Object.assign(reportedprops,
			      // {
			      // 	  ccdetails : {
			      // 	      TagId : tagpayload.TagId ? tagpayload.TagId : "unknown-wsn-id",
			      // 	      LastShipmentDetails : {
			      // 		  id         : shipment.id,
			      // 		  shipmentId : shipment.shipmentId,
			      // 	      }
			      // 	  }
			      // },
		 	      Twinschemas.map_base(sensordatamsg),
			      Twinschemas.schemas.telemetry);

		// Object.assign(reportedprops,
		// 	      {
		// 		  ccdetails : {
		// 		      TagId : tagpayload.TagId ? tagpayload.TagId : "unknown-wsn-id"
		// 		  }
		// 	      },
		// 	      Twinschemas.map_base(sensordatamsg),
		// 	      Twinschemas.schemas.temperature,
		// 	      Twinschemas.schemas.humidity,
		// 	      Twinschemas.schemas.pressure,
		// 	      Twinschemas.schemas.tilt,
		// 	      Twinschemas.schemas.shock,
		// 	      Twinschemas.schemas.light,
		// 	      Twinschemas.schemas.battery,
		// 	      Twinschemas.schemas.telemetry);

		//Logging.msg("reported props, dump: ", reportedprops);

    		//now test updating the reported properties
    		tagtwin.properties.reported.update(reportedprops, function(err, res) {
    		    if(err) {
    			Logging.msg("error updating twin, err dump: ", err);
    			Logging.msg("error updating twin: " + err.name);
    			donecb("error updating twin: " + err.name);
			return;
    		    }
    		    Logging.msg("updated twin!");
    		    donecb(null, taghubclient);
    		});
	    });
	},
	function(taghubclient, donecb) {

	    taghubclient.open(function(err) {
		//Logging.msg("hubclient object dump:", hubclient);

		/* we break out if we can't even connect! */
		if(err) {
		    Logging.msg(Errorlist.hubconnect.msg, err);
		    donecb(err);
		    return;
		}

		/* first send a location msg */
		sendlocationmsg(taghubclient, function(err) {
		    if(err){
			Logging.msg("error sending location msg, continuing...");
		    }
		});

		/* then send the rest of the sensor messages */
		sendsensormsgs(taghubclient, donecb);

	    });
	    function sendlocationmsg(client, donecb) {

		var locationdata = Twinschemas.map_location_fields(sensordatamsg);
		var timestamp = new Date();

		/* send to iot hub */
		var hubreadymsg = new DeviceMessage(JSON.stringify(locationdata));
		hubreadymsg.properties.add('$$CreationTimeUtc', timestamp.toISOString());
		hubreadymsg.properties.add('$$MessageSchema', Twinschemas.schemas.names['location']);
		hubreadymsg.properties.add('$$ContentType', 'JSON');

		Logging.msg("sending sensor data message to iot/pcs2 hub, dump: ", hubreadymsg);

		/* update in internal DB via dal ..so viz portal can see via shipping APIs */
		function updatedal() {
		    Logging.msg("+updatedal()");
		    try {
			if(shipment) {
			    Logging.msg("about to update location in shipping record...");
			    shipment.update({
				telemetryReportingTime : timestamp,
				telemetryLatitude      : sensordatamsg.location.latitude,
				telemetryLongitude     : sensordatamsg.location.longitude,
			    }).then(function(ok) {
				Logging.msg("updatedal shipment location success!");
			    },function(err) {
				Logging.msg("updatedal shipment location error!");
			    });
			}
			else {
			    Logging.msg("shipment record not valid in updatedal() ..can't update location");
			}
		    }
		    catch(err) {
			Logging.msg("caugh err in then()", {obj: err});
		    }

		}
		setImmediate(updatedal);

		client.sendEvent(hubreadymsg, function(err,res) {
		    if(err) {
	    		Logging.msg("error sending location msg, continuing", err);
		    }
		    else {
	    		Logging.msg("success sending location: TagId: 0x" + tagpayload.tagId.toString(16));
		    }

		    if(res){
			//turning off to reduce noise
	    		Logging.msg("D2C send result", res);
		    }

		    /* note ..we keep going even if there was an error...*/
		    donecb(null);
		});
	    }

	    /* sends the individual messages using the passed in client*/
	    function sendsensormsgs(client, donesendcb) {

		Async.each(tagpayload.sensorData, function(sensor,donecb) {
		    Logging.msg("about to send sensor data, dump: ", sensor);

		    /* now, send the sensor data for this tag */
		    try {
			var sensordata = Twinschemas.map_sensor_fields(sensor.type, sensor);
			Logging.msg("sensor data msg dump:", sensordata);
		    }
		    catch(err){
			Logging.msg("unsupported sensor type in tag payload: " + sensor.type);
			Logging.msg("unsupported sensor type, dump:",  err);

			/* this is an IGNORE, not error we blow up on ..for now */
			donecb(null);
			return;
		    }

		    var timestamp = new Date();
		    var hubreadymsg = new DeviceMessage(JSON.stringify(sensordata));
		    hubreadymsg.properties.add('$$CreationTimeUtc', timestamp.toISOString());
		    hubreadymsg.properties.add('$$MessageSchema', Twinschemas.schemas.names[sensor.type]);
		    hubreadymsg.properties.add('$$ContentType', 'JSON');

		    Logging.msg("sending sensor data message to iot/pcs2 hub, dump: ", hubreadymsg);

		    client.sendEvent(hubreadymsg, function(err,res) {
			if(err) {
	    		    Logging.msg("error sending tag data msg, continuing", err);
			}
			else {
	    		    Logging.msg("success sending tag sensor: " + sensor.type +
			    		" TagId: 0x" + tagpayload.tagId.toString(16));
			}

			if(res){
			    //turning off to reduce noise
	    		    Logging.msg("D2C send result", res);
			}
			/* note ..we keep going even if there was an error...*/
			donecb(null);
		    });

		}, function(err) {
		    if(err){
			Logging.msg("error sending sensor data");
			donecb(err);
			return;
		    }

		    var successmsg = "success sending sensor data for tagpayload.TagId: " + tagpayload.tagId;
		    Logging.msg(successmsg);
		    donesendcb(null,successmsg);
		});
	    }

	}
    ], function(err, results) {
	if(err){
	    Logging.msg("error working with SensorData msg payload: ", err);
	    finaldonecb(err);
	    return;
	}

	Logging.msg("success complete tag proxy ops");
	Logging.msg("tag proxy ops results dump:", results);
	finaldonecb(null);
    });

}

/**
   Wrapper for orderly shutdown

   @param msg - an optional message to be emitted on shutdown

   @return calls
*/
function shutdown(msg, errorcode) {


    Logging.msg("shutting down...");

    if (typeof errorcode !== 'number') {
	Logging.msg("Non numeric error code passed into shutdown() ..using 255 instead");
	errorcode = 255
    }

    if(typeof msg === "string"){
	Logging.msg(msg);
    }

    /* this puts process.exit() at end of node event loop
       ofcourse, if anything hangs forever, we'll have to initiate
       some other more drastic kill procedure */
    setImmediate(function(){
	process.exit(errorcode);
    });
}


/**
   using 'main' for readability

   @return nothing - code will call shutdown() which will exit the tool with and error codes
*/
function main() {

    Logging.msg("+main()");

    //Logging.msg("available configuration items in Commonconfig:", Commonconfig);
    //Logging.msg("error list: ", Errorlist);

    function onerror(err) {
	Logging.msg("error from gwsendrecv: ", err);
	shutdown(err.msg, err.code);
    }

    //in order to receive messages from the past, set msgs after to a time in the past
    //var startDate = new Date();
    //startDate.setDate(startDate.getDate() - 1);

    /* yes.... we use same hub config as gwlistener ..its not an error */
    var options = {
	hubendpoint : Commonconfig.gwlistener.event_hub_compatible_endpoint(),
	hubname     : Commonconfig.gwlistener.event_hub_name(),
	handlertable: handlertable,
	callername  : "gwtagproxy",
	errorcb     : onerror,
	msgsafter   : Date.now(),
	//msgsafter   : startDate.getUTCMilliseconds(),
    };

    /* remember: this is listening for south-to-north messages on the
       *gateway* iot hub! */
    Gwsendrecv.receive_from_gw(options);

}

main();
