#!/bin/bash

export NODE_PATH=".";
node gwtagproxy.js
