var listener = require('./listener')

module.exports = function (context, IoTHubMessages) {
    context.log('IoTHubMessages: ' + JSON.stringify(IoTHubMessages));
    context.log('context: ' + JSON.stringify(context));

    if (context.bindingData.systemProperties.hasOwnProperty('enqueuedTimeUtc'))
        var receivedTime = context.bindingData.systemProperties.enqueuedTimeUtc;
    else
        var receivedTime = Date.now();
    var message = {
        "receivedTime": receivedTime,
        "messageType": context.bindingData.properties.southnorth_msgid,
        "message": IoTHubMessages
    }
    listener.storeGwData(context, message);
};