"use strict";

var https = require('https');
var listener = require('./listener');


exports.computeGeoLocation = function(context, message) {
  //context.log("\ncomputeGeoLocation: " + JSON.stringify(message));
    var gwMessage = message;
    var msgPayload = gwMessage.message;
    if(msgPayload.hasOwnProperty('location')){
      var networkLocationStructure = {};
      var isLocationDataAvailable = false;
      if(msgPayload.location.hasOwnProperty('cellTowers')){
        isLocationDataAvailable = true;
        networkLocationStructure.cellTowersArray = msgPayload.location.cellTowers;
      }
      if(msgPayload.location.hasOwnProperty('wifiAccessPoints')){
        isLocationDataAvailable = true;
        networkLocationStructure.wifiAccessPointsArray = msgPayload.location.wifiAccessPoints;
      }
      if (isLocationDataAvailable){
        setImmediate(getGeoLocation, context, networkLocationStructure, gwMessage, geoCallback);
      } else {
        context.done();
      }
    }else{
      context.done();
      return;
    }
};

function getGeoLocation(context, networkLocationStructure, gwMessage, callback) {
  //context.log("\ngetGeoLocation: " + JSON.stringify(gwMessage));
    var https_header = {
        host : 'www.googleapis.com',
        port : 443,
        path : '/geolocation/v1/geolocate?key=' + process.env.GOOGLE_API_KEY,
        method : 'POST',
        headers: { 'Content-Type': 'application/json' },
    };
    var https_body = {
        "considerIp": "false",
        "cellTowers": networkLocationStructure.cellTowersArray,
        "wifiAccessPoints": networkLocationStructure.wifiAccessPointsArray
    }
    //context.log("Geolocation Request header: " + JSON.stringify(https_header));
    //context.log("Geolocation Request body: " + JSON.stringify(https_body));
    var reqGet = https.request(https_header, function(res) {
        var glaLocation = {}
        glaLocation.statusCode = res.statusCode;
        glaLocation.headers = res.headers;
        context.log("GeoLocation Response statusCode: " + glaLocation.statusCode);
        //context.log("GeoLocation Response headers: " + JSON.stringify(glaLocation.headers));
        res.on('data', function(responseLocation) {
          context.log("GeoLocation Response body: " +  responseLocation);
            if (res.statusCode == 200){
                glaLocation.locationData = JSON.parse(responseLocation);
                callback(context, null, glaLocation, gwMessage);
            } else {
              context.log("Error: " + res.statusCode);
              glaLocation.locationData = JSON.parse(responseLocation);
              callback(context, "Error", glaLocation, gwMessage);
            }
            reqGet.end();
        });
    });

    reqGet.on('error', function(error) {
        context.log("GeoLocation Error: " + error);
        callback(context, "Error: " + error, null, gwMessage);
    });

    reqGet.setTimeout(60000, function(){
        context.log('https request timedout');
        reqGet.abort();
        callback(context, "Error: https Timeout", null, gwMessage);
    }.bind(reqGet));

    reqGet.on('socket', function (socket) {
        socket.setTimeout(60000, function() {
            context.log('socket timeout');
            callback(context, "Error: Socket Timeout", null, gwMessage);
            reqGet.abort();
        });
    });
    reqGet.write(JSON.stringify(https_body));
    reqGet.end();
}

function geoCallback(context, error, glaLocation, gwMessage){
  //context.log("\ngeoCallback: " + JSON.stringify(gwMessage));
  var msgPayload = gwMessage.message;
    if ((error == null)&&(glaLocation.statusCode == 200)){
      msgPayload.location.glaPosition = {};
      msgPayload.location.glaPosition.location = glaLocation.locationData.location;
      msgPayload.location.glaPosition.accuracy = glaLocation.locationData.accuracy;
      msgPayload.location.glaPosition.timeOfPosition = Date.now();
      if(msgPayload.location.locationMethod == "NoPosition"){
        context.log("Replacing Location information in SensorData payload: " + JSON.stringify(glaLocation.locationData));
        msgPayload.location.latitude = glaLocation.locationData.location.lat;
        msgPayload.location.longitude = glaLocation.locationData.location.lng;
        msgPayload.location.positionUncertainty = glaLocation.locationData.accuracy;
        msgPayload.location.locationMethod = "GLA-From-GVA";
        msgPayload.location.timeOfPosition = msgPayload.location.glaPosition.timeOfPosition;
        msgPayload.location.altitude = -1;
      }
    } else {
      msgPayload.location.glaPosition = {}; msgPayload.location.glaPosition.error = {};
      msgPayload.location.glaPosition.error.error = error;
      if (glaLocation != null){
              msgPayload.location.glaPosition.error.status = glaLocation.statusCode;
              msgPayload.location.glaPosition.error.header = glaLocation.headers;
              msgPayload.location.glaPosition.error.responseBody = glaLocation.locationData;
      }
    }
    gwMessage.message = msgPayload;
    listener.updateGwData(context, gwMessage);
    return;
}
