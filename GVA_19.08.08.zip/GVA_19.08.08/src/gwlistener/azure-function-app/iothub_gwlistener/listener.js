"use strict";
var GeoLocation = require('./geolocation');
const url = process.env.MONGODB_URL;
const auth = {
  auth: {
    user: process.env.MONGODB_USER,
    password: process.env.MONGODB_PASSWORD
  }
};
const collection = 'sensordatas'

exports.storeGwData = function (context, gwData) {
  context.log("received time: " + gwData.receivedTime);
  context.log("message type: " + gwData.messageType);
  //context.log("message received: " + JSON.stringify(gwData.message));
  var MongoClient = require('mongodb').MongoClient(url, auth);
  MongoClient.connect(function (err, db) {
    if (err || (db == null)) {
      context.log("MongoClient.connect() Error: " + err);
      context.done();
      return;
    }
    db.db('admin')
      .collection(collection)
      .insertOne({
          "receivedTime": gwData.receivedTime,
          "messageType": gwData.messageType,
          "message": gwData.message
        },
        function (err, result) {
          if (err) {
            context.log("DB Error inserting data: " + err);
            db.close();
            context.done();
            return;
          }
          context.log("\nStored GW Data to MongoDB, Result: " + JSON.stringify(result.result) + ", _id: " + result["ops"][0]["_id"]);
          gwData._id = result["ops"][0]["_id"];
          db.close();
          setImmediate(GeoLocation.computeGeoLocation, context, gwData);
          //context.done();
        });
  });
}

exports.updateGwData = function (context, gwData) {
  //context.log("updateGwData: " + JSON.stringify(gwData));
  var MongoClient = require('mongodb').MongoClient(url, auth);
  MongoClient.connect(function (err, db) {
    if (err || (db == null)) {
      context.log("MongoClient.connect() Error: " + err);
      context.done();
      return;
    }
    context.log("Updating _id: " + gwData._id);
    var query = {
      _id: gwData._id
    }
    var insertObject = {
      $set: {
        "receivedTime": gwData.receivedTime,
        "messageType": gwData.messageType,
        "message": gwData.message
      }
    };
    db.db('admin')
      .collection(collection)
      .updateOne(query, insertObject,
        function (err, result) {
          if (err) {
            context.log("db.collection().updateOne() Error: " + err);
            db.close();
            context.done();
            return;
          }
          context.log("Update Result: " + result);
          db.close();
          context.done();
          return;
        });
  });
}