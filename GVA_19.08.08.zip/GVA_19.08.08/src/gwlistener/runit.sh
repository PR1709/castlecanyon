#!/bin/bash

export NODE_PATH=".";
node gwlistener.js
