/*
  File: gwlistener.js

  Description:
  Main etry point for the gwlistener process / code

  License:
  Intel TODO

*/

'use strict';

/* logging ..*/
const Logging = require('cccommon/logging').logger("gwlistener");
Logging.enable();

/* modules that are part of this tool's codebase */
const Commonconfig = require('cccommon/config');
const Northsouth = require('cccommon/northsouth');
const Gwsendrecv = require('cccommon/gwsendrecv');
const shipDal = require('cccommon/dal/shipment');
const geofenceDal = require('cccommon/dal/geofence');
const smsAlert = require('cccommon/alerts/sms');
const gwmClient = require('cccommon/client/gwmessenger');

/* modules that are part of this tool's codebase */
const GeoLocation = require('./geolocation');
const Geofence = require('./geofence');
const SensorDataHandlers = require('./sensordata')
const StoreToDb = require('./storetodb');

/**
   Wrapper for orderly shutdown

   @param msg - an optional message to be emitted on shutdown

   @return calls
*/
function shutdown(msg, errorcode) {
  Logging.msg("shutting down...");

  if (typeof errorcode !== 'number') {
    Logging.msg("Non numeric error code passed into shutdown() ..using 255 instead");
    errorcode = 255
  }

  if (typeof msg === "string") {
    Logging.msg(msg);
  }

  /* this puts process.exit() at end of node event loop
     ofcourse, if anything hangs forever, we'll have to initiate
     some other more drastic kill procedure */
  setImmediate(function () {
    process.exit(errorcode);
  });
}


var handlertable = {};

handlertable[Northsouth.northbound.msgids.test] = function (msgid, msg) {
  Logging.msg("RX msg: " + msgid);
  //Logging.msg("RX msg dump:", msg.message);

  // Write any logic here

  // storing GW data to external DB
  setImmediate(StoreToDb, msg, function (err) {
    if (err) {
      Logging.msg(err);
      return;
    }
    Logging.msg("Stored sensordata to External DB");
  });
  return;
}

handlertable[Northsouth.northbound.msgids.configchange] = function (msgid, msg) {
  Logging.msg("RX msg: " + msgid);
  //Logging.msg("RX msg dump:", msg.message);

  // Write any logic here

  // storing GW data to external DB
  setImmediate(StoreToDb, msg, function (err) {
    if (err) {
      Logging.msg(err);
      return;
    }
    Logging.msg("Stored sensordata to External DB");
  });
  return;
}

handlertable[Northsouth.northbound.msgids.association] = function (msgid, msg) {
  Logging.msg("RX msg: " + msgid);
  //Logging.msg("RX msg dump:", msg.message);

  // Write any logic here

  // storing GW data to external DB
  setImmediate(StoreToDb, msg, function (err) {
    if (err) {
      Logging.msg(err);
      return;
    }
    Logging.msg("Stored sensordata to External DB");
  });
  return;
}

handlertable[Northsouth.northbound.msgids.disassociation] = function (msgid, msg) {
  Logging.msg("RX msg: " + msgid);
  //Logging.msg("RX msg dump:", msg.message);

  // Write any logic here

  // storing GW data to external DB
  setImmediate(StoreToDb, msg, function (err) {
    if (err) {
      Logging.msg(err);
      return;
    }
    Logging.msg("Stored sensordata to External DB");
  });
  return;
}

handlertable[Northsouth.northbound.msgids.associationcomplete] = function (msgid, msg) {
  Logging.msg("RX msg: " + msgid);
  //Logging.msg("RX msg dump:", msg.message);

  // Write any logic here

  // storing GW data to external DB
  setImmediate(StoreToDb, msg, function (err) {
    if (err) {
      Logging.msg(err);
      return;
    }
    Logging.msg("Stored sensordata to External DB");
  });
  return;
}

handlertable[Northsouth.northbound.msgids.sensordata] = function (msgid, msg) {
  Logging.msg("RX msg: " + msgid + " for Shipment: " + msg.message.shipmentId);
  //Logging.msg("RX msg dump:", msg.body);
  setImmediate(SensorDataHandlers.processSensorData, msg, function (err) {
    if (err) {
      Logging.msg("Error Processing SensorData: " + err);
      return;
    }
    Logging.msg("SensorData was processed successfully");
  });
}

//this is a default handler
handlertable['**DEFAULT**'] = function (msgid, msg) {
  Logging.msg("RX msg: " + msgid);
  Logging.msg("RX msg dump:", msg,message);

  // Write any logic here

  // storing GW data to external DB
  setImmediate(StoreToDb, msg, function (err) {
    if (err) {
      Logging.msg(err);
      return;
    }
    Logging.msg("Stored sensordata to External DB");
  });
  return;
}

/**
   using 'main' for readability

   @return nothing - code will call shutdown() which will exit the tool with and error codes
*/
async function main() {

  Logging.msg("+main()");

  //Logging.msg("available configuration items in Commonconfig:", Commonconfig);
  //Logging.msg("error list: ", Errorlist);

  function onerror(err) {
    Logging.msg("error from gwsendrecv: ", err);
    shutdown(err.msg, err.code);
  }

  //in order to receve messages from the past, set msgs after to a time in the past
  //var startDate = new Date();
  //startDate.setDate(startDate.getDate() - 1);

  var options = {
    hubendpoint: Commonconfig.gwlistener.event_hub_compatible_endpoint(),
    hubname: Commonconfig.gwlistener.event_hub_name(),
    handlertable: handlertable,
    callername: "gwlistener",
    errorcb: onerror,
    msgsafter: Date.now(),
    //msgsafter   : startDate.getUTCMilliseconds(),
  };

  Gwsendrecv.receive_from_gw(options);
}

main();
