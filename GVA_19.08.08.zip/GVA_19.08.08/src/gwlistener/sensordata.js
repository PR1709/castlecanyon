/*
  File: sensordata.js

  Description:
  takes care of sensor data received from GW

  License:
  Intel TODO

*/
'use strict';

/* logging ..*/
const Logging = require('cccommon/logging').logger("gwlistener.sensordata");
Logging.enable();

/* gva common modules */
const shipDal = require('cccommon/dal/shipment');

/* gw listener modules */
const StoreToDb = require('./storetodb');
const GeoLocation = require('./geolocation');
const Geofence = require('./geofence');

exports.processSensorData = async function (payload) {
  //Logging.msg("payload: " + JSON.stringify(payload));
  //Check for GPS location, if not, try and update with GLA
  var newPayload = await checkAndUpdateLocation(payload);

  //Logging.msg("newPayload: " + JSON.stringify(newPayload));
  // Store sensor data to the MongoDB
  storeSensorData(newPayload);

  if (newPayload.message.location.locationMethod != "NoPosition") {
    // Update the Shipment Record with the last know location
    updateShipmentLocation(newPayload);

    // Process any GeoFence Rules
    processGeofence(newPayload);
  } else
    Logging.msg("No Location information to update shipment record or process geofence");

}

async function checkAndUpdateLocation(payload) {
  var msgPayload = payload.message;

  // incase position has been provided by GW, dont override in GVA
  if (msgPayload.location.locationMethod != "NoPosition") {
    getGeoLocation = false;
    return (payload);
  }

  // first establish if there is sufficient info to perform GeoLocation
  var getGeoLocation = false;
  var networkLocationStructure = {};
  if (msgPayload.location.hasOwnProperty('cellTowers')) {
    getGeoLocation = true;
    networkLocationStructure.cellTowersArray = msgPayload.location.cellTowers;
  }
  if (msgPayload.location.hasOwnProperty('wifiAccessPoints')) {
    getGeoLocation = true;
    networkLocationStructure.wifiAccessPointsArray = msgPayload.location.wifiAccessPoints;
  }

  if (getGeoLocation) {
    // sufficient info available, proceed with geolocation.
    return await GeoLocation(networkLocationStructure)
      .then(async function (resolve) {
        glaLocation = resolve;
        Logging.msg("Replacing Location information in SensorData payload: " + JSON.stringify(glaLocation.locationData));
        msgPayload.location.latitude = glaLocation.locationData.location.lat;
        msgPayload.location.longitude = glaLocation.locationData.location.lng;
        msgPayload.location.positionUncertainty = glaLocation.locationData.accuracy;
        msgPayload.location.timeOfPosition = Date.now();
        // GLA-From-GVA indicates geolocation was performed in GVA..
        msgPayload.location.locationMethod = "GLA-From-GVA";
        msgPayload.location.altitude = -1;
        // updated original payload
        payload.message = msgPayload;
        return payload;
      })
      .catch(async function (reject) {
        Logging.msg("Error while performing GeoLocation: " + reject);
        // if GeoLocation was not performed for any reason, return original payload.. 
        return payload;
      })
  } else
    return payload;
}

function storeSensorData(payload) {
  //Commented out storing of sensor data as this is now done in the Azure Function App
  //Logging.msg("Storing SensorData Msg: " + JSON.stringify(payload));
  setImmediate(StoreToDb, payload, function (err) {
    if (err) {
      Logging.msg(err);
      return;
    }
    Logging.msg("Stored sensordata to External DB");
  });
  return;
}

function updateShipmentLocation(payload) {
  var shipmentid = payload.message.shipmentId;
  if (isNaN(shipmentid)) {
    Logging.msg("using shipDal.findByShipmentId for shipment lookup: " + shipmentid);
    var queryFn = shipDal.findByShipmentId;
  } else {
    Logging.msg("using shipDal.findByPrimaryKey for shipment lookup: " + shipmentid);
    var queryFn = shipDal.findByPrimaryKey;
  }
  queryFn(shipmentid)
    .then(function (shipment) {
      if (shipment) {
        Logging.msg("about to update location in shipping record...");
        shipment.update({
          telemetryReportingTime: payload.message.location.timeOfPosition,
          telemetryLatitude: payload.message.location.latitude,
          telemetryLongitude: payload.message.location.longitude,
        }).then(function (ok) {
          Logging.msg("shipment location updated successfully!");
        }, function (err) {
          Logging.msg("while updating shipment location error occurred: " + err);
        });
      } else {
        Logging.msg("shipment record not valid in database..can't update location!");
      }
    })
}

function processGeofence(payload) {
  Geofence.checkAndNotifyGeofenceAlert(payload);
}
