/*
  File: storeToDd.js

  Description:
  Stores data in MongoDB

  License:
  Intel TODO

*/
'use strict';

/* logging ..*/
const Logging = require('cccommon/logging').logger("gwlistener.storeToDb");
Logging.enable();

/* gva common mondules */
const sensorDal = require('cccommon/dal/sensordata');
const Commonconfig = require('cccommon/config');

//store any kind of data into DB.
module.exports = function(sensorData, doneCb) {
    // check if the process in VM flag is enabled,, 
    var result = false;
    if (Commonconfig.gwlistener.store_data() == 'enable') {
        result = sensorDal.insertSample(sensorData);
    }
    doneCb(result);
}
