#!/bin/bash

export NODE_PATH=".";
node gwmessenger.js
