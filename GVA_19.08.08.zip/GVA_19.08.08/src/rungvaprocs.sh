#!/bin/bash
#
# Launch script for GVA processes running in a "big single" container
#

CCROOT="/home/ubuntu/castle_canyon"

cd $CCROOT
chmod +x ./internaldb/bin/migrate ./internaldb/bin/first_deploy_seeder ./internaldb/bin/dev_only_seeder ./internaldb/bin/seq
./internaldb/bin/migrate
./internaldb/bin/first_deploy_seeder
./internaldb/bin/dev_only_seeder

cd $CCROOT/gwlistener
pm2 start gwlistener.js --node-args="--max_old_space_size=1000"

#disabled gwtagproxy as it is not being maintained
#cd $CCROOT/gwtagproxy
#pm2 start gwtagproxy.js --node-args="--max_old_space_size=1000"

cd $CCROOT/gwmessenger
pm2 start gwmessenger.js --node-args="--max_old_space_size=1000"

cd $CCROOT/shippingapi
pm2 start shippingapi.js --node-args="--max_old_space_size=1000"

cd $CCROOT/keystore
pm2 start keystore.js --node-args="--max_old_space_size=1000"

while [ 1 -eq 1 ]; do
    # this won't return ..but I'm guessing its good to have here for now
    # so that if we attach we'll start seeing GVA logs come out
    pm2 logs

    # note this is a good place to look at jobs status from pm2 and send to external
    # monitoring service
    sleep 30
done
