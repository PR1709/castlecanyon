'use strict';

module.exports = (sequelize, DataTypes) => {
  const Gateway = sequelize.define('Gateway', {
    uuid: {
      type: DataTypes.STRING,
      allowNull: false
    },
    wsnId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    panId: {
      type: DataTypes.STRING,
      allowNull: false
    },
    channelId: {
      type: DataTypes.STRING,
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  });

  Gateway.associate = (models) => {
    Gateway.ShippingUnit = Gateway.hasMany(models.ShippingUnit, {
      foreignKey: 'gatewayId',
      as: 'shippingUnits'
    });

    // One of several associations among all the models that are intended to support "reverse"
    // look ups in order to (ultimately, in DAL functions) find shipments that currently
    // use a given tag (identified by UUID in the actual query).
    Gateway.Shipment = models.Shipment.belongsToMany(models.Shipment, {
      through: 'ShipmentGateway',
      foreignKey: 'gatewayId',
      otherKey: 'shipmentId',
      as: 'shipments'
    });
  };

  return Gateway;
};
