'use strict';

module.exports = (sequelize, DataTypes) => {
  const ShippingUnit = sequelize.define('ShippingUnit', {
    gatewayId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    packageId: {
      type: DataTypes.STRING,
      allowNull: false
    },
    createdAt: {
      type: DataTypes.DATE,
      allowNull: false
    },
    updatedAt: {
      type: DataTypes.DATE,
      allowNull: false
    }
  });

  ShippingUnit.associate = (models) => {
    // One of several associations among all the models that are intended to support "reverse"
    // look ups in order to (ultimately, in DAL functions) find shipments that currently
    // use a given tag (identified by UUID in the actual query).
    ShippingUnit.Gateway = ShippingUnit.belongsTo(models.Gateway, {
      foreignKey: 'gatewayId',
      as: 'gateway'
    });

    ShippingUnit.Tag = ShippingUnit.belongsToMany(models.Tag, {
      through: 'ShippingUnitTag',
      foreignKey: 'shippingUnitId',
      otherKey: 'tagId',
      as: 'tags'
    });
  };

  return ShippingUnit;
};
