const Logging   = require('cccommon/logging').logger('common.dal.gateway');
Logging.enable();

const models = require('cccommon/models/internaldb');

/**
 * Find the gateway and all associated shipments.
 *
 * The purpose is to support "reverse" look ups in order to find out if a shipment
 * already exists that's associated the given gateways, in order to prevent multiple
 * shipments from using the same gateway.
 */
exports.findByUUID = (uuid) => {
  return models.Gateway.findAll({
    where: {
      uuid: uuid
    },
    include: [models.Gateway.Shipment]
  });
};
