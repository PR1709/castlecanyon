/*
  File: sensordata.js

  Author: sharath.srinivasan@intel.com

  Description:
  storage of sensor data in external database

  License:
  Intel TODO

*/

'use strict';

const Logging = require('cccommon/logging').logger('common.dal.sensordata');
Logging.enable();
const Commonconfig = require('cccommon/config');
const mongoose = require('mongoose');

mongoose.connect(Commonconfig.externaldb.uri(), Commonconfig.externaldb.auth())
  .then(() => console.log('Successfully connected to the externalDB (MongoDB)...'))
  .catch((err) => console.error("Error connecting to externalDB: " + err));

var Schema = mongoose.Schema;
var userSchema = new Schema({
  receivedTime: Number,
  messageType: String,
  message: {}
});
//var sensorDataModel = mongoose.model('gw_northbounds', userSchema);
var sensorDataModel = mongoose.model('sensordatas', userSchema);

exports.insertSample = (sensorData) => {
  var newSensorData = new sensorDataModel(sensorData);
  
  newSensorData.save(function(err) {
    if (err) {
        Logging.msg("Error: " + err);
	return "Error: Saving Sensor Data into externalDB";
    }
    Logging.msg("saved the sensordata");
    return null;
  });
}

exports.findByShipmentId = (shipmentId, callback) => {
  sensorDataModel.find({'message.shipmentId':shipmentId.toString()},function(err, data) {
    if (err) {Logging.msg(err, data); return;}
    //Logging.msg("SensorData DAL: " + data);
    callback(null, data);
  })
}

exports.deleteByShipmentId = (shipmentId, callback) => {
  sensorDataModel.remove({ 'message.shipmentId': shipmentId.toString() }, function (err, data) {
    if (err) { Logging.msg(err, data); return; }
    //Logging.msg("SensorData DAL: " + data);
    callback(null, data.n);
   })
}

