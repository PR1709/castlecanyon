/*
  File: gwsendrecv.js

  Description:
  Common send and receive helper functions used by all modules
  that need to communicate with a physical gateway device via
  Azure IoT hub or any other transport

  License:
  Intel TODO

*/

'use strict';

/* logging ..*/
const Logging   = require('cccommon/logging').logger("gwsendrecv");
Logging.enable();

/* modules that are part of this tool's codebase */
const Commonconfig   = require('cccommon/config');
const Errorlist      = require('cccommon/errorlist').errorlist;
const Northsouth     = require('cccommon/northsouth');

/* misc utility modules from npmjs.org */
const async          = require('async');

/* Azure related -- IoT hub and friends (also from npmjs.org) */
const { EventHubClient, EventPosition } = require('azure-event-hubs');
const IotHubClient   = require('azure-iothub').Client;
const Message        = require('azure-iot-common').Message;

/**
   receive loop for device to cloud messages coming from the gateway IoT Hub
   (casted as an EventHub due to it having EventHub compatible interfaces

   options object requires this template (all values!):
    {
        hubendpoint : event hub compatible endpoint string
        hubname     : event hub name
        handlertable: handlertable,
        callername  : "your module name string",
        errorcb     : f(err)
    }

    handlertable is a list of keynames mapped to functions.
      - each keyname should be a value from sourceroot/common/northsouth/northsouth.js
    {
       "Northsouth.xxx.msdids.yyyy" = function(msgid,msg),
    }
*/
exports.receive_from_gw = function (options) {
	async function initiateConnection() {
		var partitionIds;
                var receiveHandler = [];
                Logging.msg("+ initiateConnection()");
		const onMessage = (eventData) => {
			//Logging.msg("eventData: " + JSON.stringify(eventData));
			const enqueuedTime = eventData.annotations["x-opt-enqueued-time"];
                        const msgId = eventData.applicationProperties.southnorth_msgid;
			//Logging.msg("Enqueued Time: " + enqueuedTime + ", msg: " + msgId);
                        var process = options.handlertable[msgId];
                        if (! process) {
                           process = options.handlertable['**DEFAULT**'];
                           return;
                        }
                        var incomingSensorData = {
                           receivedTime: enqueuedTime,
                           messageType: msgId,
                           message: eventData.body
                        };
                        setImmediate(process, msgId, incomingSensorData);
		};
		const onError = (err) => {
			Logging.msg("An error occurred on the receiver ", err);
		};
		async function register(){
			Logging.msg("+ in register()");
			const client = await EventHubClient.createFromConnectionString(options.hubendpoint, options.hubname);
			partitionIds = await client.getPartitionIds();
			Logging.msg(partitionIds, partitionIds.length);
			for (var i = 0; i < partitionIds.length; i++) {
			  receiveHandler[i] = client.receive(partitionIds[i],
							onMessage,
							onError,
							{eventPosition: EventPosition.fromEnqueuedTime(Date.now())});
			}
		   }
		   register();
	}

	/* implemented additional function call to initiateConnection, to handle error condition */
	function start() {
		Logging.msg("+ start()");
		initiateConnection().catch((err) => {
				Logging.msg("error with initiating connection, re-trying..");
				start();
				return;
			})
	}

	start();
}

/**
   Sends a device a Cloud to Device message to the physical gateway device

   @param opttions : see options template below

   @param deviceid :  the device id value - which is the devices unique identifer in the
               the device registry. This can be found in the Azure Dashbaord's IoT Hub
               resource, under "Device Explorer".

   @param  msg  : object with the payload for the north-to-south message,


   The options object requires the following values:
   {

     svcstring : "service polity connect string",
     callername : "name of calling module"

   }

   The 'msg' object should follow this template:
   {
     data        : "raw data as a string",
     properties  : {
       "some-key-name1" : "value 1",
       "some-key-name2" : "value 2",
       ...
     }
   }

   @return nothing
*/
exports.send_to_gw = function(options, deviceid, msg) {
  return new Promise(function(resolve, reject) {
    /* this try block isolates azure library stuff */
    try {
	var hubclient = IotHubClient.fromConnectionString(options.svcstring);
	Logging.msg("openiot hub as a service for " + options.callername);
	hubclient.open(function (err) {
	    //Logging.msg("hubclient object dump:", hubclient);
	    if(err) {
		Logging.msg(Errorlist.hubconnect.msg, err);
                reject(err);
	    }

	    /* good to go!! */
	    Logging.msg("connected to the IoT hub, yay!");
	    /* send the device the msg - data as JSON string!!*/
	    var hubreadymsg = new Message(JSON.stringify(msg.data));
	    for ( var key in msg.properties) {
		hubreadymsg.properties.add(key, msg.properties[key]);
	    }
	    //Logging.msg("TX msg dump:", msg);
	    //Logging.msg("hubreadymsg dump:", hubreadymsg);
	    hubclient.send(deviceid, hubreadymsg,function(err,res){
	    	//Logging.msg("+ hubclient.send() callback");
	    	if(err){
                    Logging.msg("error sending north-to-south msg", JSON.stringify(err));
                    reject(err);
	    	}
		else {
	    	    Logging.msg("success sending north-to-south msg");
		}

	    	if(res) {
		    //not a lot in here, so commented out
	    	    //Logging.msg("C2D send result", res);
	    	}

		hubclient.close(function(err){
		    if(err){
			Logging.msg("Error closing hubclient...");
                        reject(err);
		    }
		    else {
			Logging.msg("closed hubclient for " + options.callername);
                        resolve();
		    }
		});
	    });
	});
    }
    catch (ex) {
	Logging.msg("caught exception in azure lib code", ex);
        reject(ex);
    }
  });
};
