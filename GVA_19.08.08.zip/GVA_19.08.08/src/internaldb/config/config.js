// sequelize-cli depends on this file (or config.json) for configuration based on its
// internal conventions.
module.exports = require('cccommon/config').internaldb.connection();
