const http = require('./http');

function main() {
  http.run();
}

main();
