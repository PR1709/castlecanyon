#!/bin/bash

IMAGE_NAME="cc-gva"
TAG="latest"
NODE_VER="8.9.0"

if [ "$1" == "" ]; then
    echo "arg 1 should be an image tag value (ex image:drop1)"
    exit 1
fi

TAG="$1"

docker build \
       --build-arg NODE_VER="${NODE_VER}" \
       -t "${IMAGE_NAME}:${TAG}" \
       -f Dockerfile .

docker tag \
       "${IMAGE_NAME}:${TAG}" "intelcastlecanyoncontainer.azurecr.io/cc-dev-builds:${TAG}"

docker push "intelcastlecanyoncontainer.azurecr.io/cc-dev-builds:${TAG}"
