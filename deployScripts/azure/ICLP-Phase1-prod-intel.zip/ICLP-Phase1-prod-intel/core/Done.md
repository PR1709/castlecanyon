## [Click here to login to ICLP portal]

**Region**  
{Location}

**Subscription ID**  
{SubscriptionId}

**Resources**  
[Click here to login to ICLP portal]

   [Click here to login to ICLP portal]: <{Outputs.oSolutionUrl}>
   